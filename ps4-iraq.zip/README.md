# PS4 Iraq
موقع عربي لعرض ألعاب PS4 مع البحث والتقييم والقصة والتريلر.
## التشغيل
افتح `index.html` في المتصفح.
## النشر
ارفع `index.html` إلى مستودع GitHub ثم فعّل GitHub Pages من Settings → Pages.
